import {
  AccountUpdate,
  Field,
  MerkleMap,
  Mina,
  PendingTransaction,
  PendingTransactionPromise,
  Poseidon,
  PrivateKey,
  PublicKey,
} from 'o1js';
import { MinaCash } from './MinaCash.js';

const Local = await Mina.LocalBlockchain({ proofsEnabled: false });
Mina.setActiveInstance(Local);

// GENERATE ACCOUNT KEYS
const deployerAccount = Local.testAccounts[0];
const deployerKey = Local.testAccounts[0].key;
const serverAccount = Local.testAccounts[1];
const serverKey = Local.testAccounts[1].key;
const userAccount = Local.testAccounts[2];
const userKey = Local.testAccounts[2].key;

const destinationKey = PrivateKey.random().toPublicKey();

// DEPLOY CONTRACT
const zkAppPrivateKey = PrivateKey.random();
const zkAppAddress = zkAppPrivateKey.toPublicKey();
const zkApp = new MinaCash(zkAppAddress);

const deployTx = await Mina.transaction(deployerAccount, async () => {
  AccountUpdate.fundNewAccount(deployerAccount);
  await zkApp.deploy();
});
await deployTx.prove();
await deployTx.sign([deployerKey, zkAppPrivateKey]).send();

// MOCK SERVER
const balanceMap = new MerkleMap();
const unstableBalanceMap = new MerkleMap();
const txNullifierMap = new MerkleMap();
const reputationMap = new MerkleMap();

// Endpoint to receive proofs
async function verifyDeposit(publicKey: PublicKey) {
  const hashedKey = Poseidon.hash(publicKey.toFields());
  const witness = unstableBalanceMap.getWitness(hashedKey);
  const prevBalance = unstableBalanceMap.get(hashedKey);

  // call smart contract
  const tx = await Mina.transaction(serverAccount, async () => {
    zkApp.verifyDeposit(publicKey, witness, prevBalance);
  });
  await tx.prove();
  await tx.sign([serverKey]).send();

  unstableBalanceMap.set(hashedKey, prevBalance.add(Field(100)));
}

async function confirmDeposit(publicKey: PublicKey, txHash: Field) {
  const hashedKey = Poseidon.hash(publicKey.toFields());
  // check if txHash has been used already
  const nullifier = txNullifierMap.get(txHash);

  if (nullifier == Field(1)) {
    console.log('Deposit already confirmed');
    return;
  } else {
    txNullifierMap.set(txHash, Field(1));
    const unstableBalance = unstableBalanceMap.get(hashedKey);

    //Check if hash references a valid deposit
    const verified = true && unstableBalance.greaterThanOrEqual(Field(100));

    if (verified) {
      const unstableWitness = unstableBalanceMap.getWitness(hashedKey);
      const stableWitness = balanceMap.getWitness(hashedKey);

      const prevStableBalance = balanceMap.get(hashedKey);

      // call smart contract
      const tx = await Mina.transaction(serverAccount, async () => {
        zkApp.makeDeposit(
          publicKey,
          unstableWitness,
          stableWitness,
          unstableBalance,
          prevStableBalance
        );
      });
      await tx.prove();
      await tx.sign([serverKey]).send();

      balanceMap.set(hashedKey, prevStableBalance.add(Field(100)));

      console.log('Deposit made');
      console.log(zkApp.balancesMapRoot.get());
    }
  }
}

//Endpoint to process payments
async function makePayment(
  publicKey: PublicKey,
  amount: Field,
  destination: PublicKey
) {
  const hashedKey = Poseidon.hash(publicKey.toFields());
  const balance = balanceMap.get(hashedKey);
  const witness = balanceMap.getWitness(hashedKey);

  // call smart contract
  const tx = await Mina.transaction(serverAccount, async () => {
    zkApp.makePayment(Field(amount), destination, witness, balance);
  });
  await tx.prove();
  await tx.sign([serverKey]).send();

  balanceMap.set(hashedKey, balance.sub(amount));

  console.log('Payment made');
  console.log(zkApp.balancesMapRoot.get().toString());
}

// MOCK USER
// Ask server for deposit
await verifyDeposit(userAccount.key.toPublicKey());
// Send tx
// call smart contract
const tx = await Mina.transaction(userAccount, async () => {
  zkApp.sendFunds(userAccount.key.toPublicKey());
  console.log('Funds sent');
  console.log(zkApp.balancesMapRoot.get().toString());
});
await tx.prove();

// GET HASH
//const res: PendingTransaction = await tx.sign([userKey]).send();
//const hash = res.hash;

await confirmDeposit(userAccount.key.toPublicKey(), Field(1));

await makePayment(userAccount.key.toPublicKey(), Field(50), destinationKey);
